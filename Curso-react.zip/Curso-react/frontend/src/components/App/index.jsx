import { useState } from 'react'
import ReactLogo from '../../assets/react.svg'
import ViteLogo from '/vite.svg'
import './style.css'
import Title from '../Title'
import Button from '../Button'
 
function App() {
  const [count, setCount] = useState(0);
  const [text, setText] = useState("abc");

  const handleInput = (newText) => {
    setText(newText.value);
    if(newText.value.length > 3){

    }
  }
  return (
    <>
    <input 
    value = {text} 
    onChange={(e) => handleInput (e.target)} type="text"/>
      <Title name= {text} paragrafo ={count > 3} />
        <div className="card">
        <button onClick={() => setCount((count) => count + 1)}>
          Contagem está em {count}
        </button>
        <p>
          Edite <code>src/App.jsx</code> e salve para testar o HMR        
        </p>
        <Button count = {count} setCount={setCount}/>
      </div>
    </>
  )
}
 
export default App