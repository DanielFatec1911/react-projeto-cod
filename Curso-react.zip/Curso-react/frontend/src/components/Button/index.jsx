//import { useState } from 'react';
import reactLogo from '../../assets/react.svg';
import viteLogo from '/vite.svg';


import './style.css';

function Button({count, setCount }) {
  //const [count, setCount] = useState(2);


  return (
    <>
      {}
      
      
        <button onClick={() => setCount((count) => count + 1)}>
          Contagem está em {count}
        </button>
 
    </>
  );
}

export default Button;